/***********************************************************************/
/*  IIC-Parallel-Interface  I2C				               */
/*  V0.1  erstellt am  : 26.10.2000                                    */
/*  Dateiname          : i2c_lpt.h				       */
/*                		       				       */
/*  Aenderungen : 						       */
/*                                                                     */
/*                                                                     */
/* 26.10.00 , Basiert auf i2c_dll.h WindowsVersion                     */
/*                                                                     */
/***********************************************************************/


#define STATUS_PORT   1
#define CONTROL_PORT  2


#include "../src/i2c_fncs.h"
